#ifndef HIL_TRANS_H
#define HIL_TRANS_H

#include "hil.h"
#include "../ssa/ssa.h"

Ssa_Prog_t Hil_trans (Hil_Prog_t p);

#endif
