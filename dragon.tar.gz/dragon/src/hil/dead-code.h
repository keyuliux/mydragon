#ifndef HIL_DEAD_CODE_H
#define HIL_DEAD_CODE_H

#include "hil.h"

Hil_Prog_t Hil_deadCode (Hil_Prog_t p);

#endif
