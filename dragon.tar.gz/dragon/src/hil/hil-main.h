#ifndef HIL_MAIN_H
#define HIL_MAIN_H

#include "hil.h"
#include "../ssa/ssa.h"

Ssa_Prog_t Hil_main (Hil_Prog_t p);

#endif
