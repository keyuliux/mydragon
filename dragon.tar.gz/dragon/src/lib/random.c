#include <stdlib.h>
#include "random.h"

int Random_nextInt ()
{
  return rand ();
}
