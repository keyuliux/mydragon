#include "void.h"

String_t Void_toString (void *s)
{
  return "()";
}
