#include "append-list.h"

#define T AppendList_t

struct T
{
  int junk;
};

T AppendList_new ()
{
  return 0;
}

#undef T
