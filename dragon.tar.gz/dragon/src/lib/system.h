#ifndef SYSTEM_H
#define SYSTEM_H

void System_run (char *cmd);

#endif
