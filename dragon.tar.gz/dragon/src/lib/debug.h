#ifndef DEBUG_H
#define DEBUG_H

void Debug_printInt (int i);

#endif
