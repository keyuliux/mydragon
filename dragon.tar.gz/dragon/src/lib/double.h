#ifndef DOUBLE_H
#define DOUBLE_H

#include "string.h"

String_t Double_toString (double f);

#endif
