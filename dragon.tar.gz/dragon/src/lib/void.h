#ifndef VOID_H
#define VOID_H

#include "string.h"

String_t Void_toString (void *s);

#endif
