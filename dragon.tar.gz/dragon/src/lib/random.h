#ifndef RANDOM_H
#define RANDOM_H

int Random_nextInt ();

#endif
