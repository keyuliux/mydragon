#ifndef LIB_TEST_H
#define LIB_TEST_H

int Lib_test ();

#endif
