#ifndef IO_H
#define IO_H

int Io_printSpaces (int n);


#endif
