#include "main/main-main.h"

int main(int argc, char **argv)
{
  Main_main (argc, argv);
  return 0;
}
