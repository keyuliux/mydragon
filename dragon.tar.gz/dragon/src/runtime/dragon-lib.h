#ifndef DRAGON_LIB_H
#define DRAGON_LIB_H

int prints (char *s);
int printi (int i);

#endif
