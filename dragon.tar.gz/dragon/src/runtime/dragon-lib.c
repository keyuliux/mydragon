#include <stdio.h>
#include "dragon-lib.h"

int prints (char *s)
{
  return printf ("%s", s);
}

int printi (int i)
{
  return printf ("%d", i);
}
