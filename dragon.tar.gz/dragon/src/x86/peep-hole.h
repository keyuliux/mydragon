#ifndef PEEP_HOLE_H
#define PEEP_HOLE_H

#include "x86.h"

X86_Prog_t PeepHole_shrink (X86_Prog_t p);


#endif
