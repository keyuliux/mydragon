#ifndef X86_CODEGEN_H
#define X86_CODEGEN_H

#include "../machine/machine.h"
#include "x86.h"

X86_Prog_t X86_codegen (Machine_Prog_t p);

#endif
