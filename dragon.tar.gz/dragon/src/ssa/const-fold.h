#ifndef SSA_CONST_FOLD_H
#define SSA_CONST_FOLD_H

#include "ssa.h"

Ssa_Prog_t Ssa_constFold (Ssa_Prog_t p);

#endif
