#include "type-check.h"

Ssa_Prog_t Ssa_typeCheck (Ssa_Prog_t p)
{
  return p;
}
