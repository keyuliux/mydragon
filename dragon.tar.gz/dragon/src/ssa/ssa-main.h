#ifndef SSA_MAIN_H
#define SSA_MAIN_H

#include "ssa.h"
#include "../machine/machine.h"

Machine_Prog_t Ssa_main (Ssa_Prog_t p);

#endif
