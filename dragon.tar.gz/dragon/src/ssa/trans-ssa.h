#ifndef TRANS_SSA_H
#define TRANS_SSA_H

#include "ssa.h"
#include "../machine/machine.h"

Machine_Prog_t Trans_ssa (Ssa_Prog_t p);

#endif
