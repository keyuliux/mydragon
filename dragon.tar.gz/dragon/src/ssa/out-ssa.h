#ifndef SSA_OUT_SSA_H
#define SSA_OUT_SSA_H

#include "ssa.h"

Ssa_Prog_t Ssa_outSsa (Ssa_Prog_t p);

#endif
