#ifndef SSA_TYPE_CHECK_H
#define SSA_TYPE_CHECK_H

#include "ssa.h"

Ssa_Prog_t Ssa_typeCheck (Ssa_Prog_t p);

#endif
