#ifndef SSA_CONSTRUCT_SSA_H
#define SSA_CONSTRUCT_SSA_H

#include "ssa.h"

Ssa_Prog_t Ssa_constructSsa (Ssa_Prog_t p);

#endif
