#ifndef SSA_CONST_PROP_H
#define SSA_CONST_PROP_H

#include "ssa.h"

Ssa_Prog_t Ssa_constProp (Ssa_Prog_t p);

#endif
