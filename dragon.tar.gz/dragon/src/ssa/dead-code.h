#ifndef SSA_DEAD_CODE_H
#define SSA_DEAD_CODE_H

#include "ssa.h"

Ssa_Prog_t Ssa_deadCode (Ssa_Prog_t p);

#endif
