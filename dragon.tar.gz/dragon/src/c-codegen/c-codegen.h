#ifndef C_CODEGEN_H
#define C_CODEGEN_H

#include "../lib/file.h"
#include "../machine/machine.h"

int C_codegen (File_t file, Machine_Prog_t p);

#endif
