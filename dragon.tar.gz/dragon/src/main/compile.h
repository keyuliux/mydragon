#ifndef COMPILE_H
#define COMPILE_H

#include "../lib/list.h"

List_t Compile_compile (List_t files);

#endif
