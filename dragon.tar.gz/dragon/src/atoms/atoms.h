#ifndef ATOMS_H
#define ATOMS_H

#include "atype.h"
#include "class.h"
#include "dec.h"
#include "id.h"
#include "label.h"
#include "operator.h"

#endif
