#ifndef LIFT_DEC_H
#define LIFT_DEC_H

#include "../ast/ast.h"

Ast_Prog_t Lift_dec (Ast_Prog_t);

#endif
