#ifndef ELABORATE_MAIN_H
#define ELABORATE_MAIN_H

#include "../ast/ast.h"
#include "../hil/hil.h"

Hil_Prog_t Elaborate_main (Ast_Prog_t p);

#endif
