#ifndef ELABORATE_H
#define ELABORATE_H

#include "../ast/ast.h"

Ast_Prog_t Elaborate_ast (Ast_Prog_t);

#endif
