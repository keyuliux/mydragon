#ifndef TRANS_AST_H
#define TRANS_AST_H

#include "../ast/ast.h"
#include "../hil/hil.h"

Hil_Prog_t Trans_ast (Ast_Prog_t);

#endif
