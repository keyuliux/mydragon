#ifndef CHECK_AST_H
#define CHECK_AST_H

#include "../ast/ast.h"

void Check_ast (Ast_Prog_t p);

#endif
