#ifndef COMBINE_STM_H
#define COMBINE_STM_H

#include "../ast/ast.h"

Ast_Prog_t Combine_stm (Ast_Prog_t);

#endif
