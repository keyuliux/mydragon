#ifndef BUFFER_H
#define BUFFER_H

void Buffer_init ();
int Buffer_getChar ();
void Buffer_putChar ();

#endif
