
//////////////////////////////////////////////////
// headers:
#include <main-header.h>


//////////////////////////////////////////////////
// strings:
static char *x_105 = " ";



//////////////////////////////////////////////////
// frames:
int argOffsets_1[] = {1 , -8};
int decOffsets_1[] = {1 , 4};

int argOffsets_2[] = {0 };
int decOffsets_2[] = {10 , 4, 8, 12, 16, 20, 24, 28, 32, 36, 40};

int frameInfo[2][3] = {
	{(int)argOffsets_1, (int)decOffsets_1, 8},
	{(int)argOffsets_2, (int)decOffsets_2, 176}
};

//////////////////////////////////////////////////
// layouts:
int layoutInfo[0][1] = {
};

//////////////////////////////////////////////////
// functions:
int x_0 (int * x_2)
{
  int * x_26;

L_6:
  *(((A)x_2)+9) = 9999;
  x_26 = *(((A)x_2)+9);
  *(((A)x_2)+0) = x_26;
  return 0;

}

int dragon ()
{
  int * x_30;
  int x_42;
  int x_94;
  int x_93;
  int x_46;
  int x_49;
  int x_51;
  int x_96;
  int x_95;
  int x_56;
  int x_68;
  int x_104;
  int x_103;
  int x_78;
  int x_29;
  int * x_13;
  int * x_35;
  int * x_88;
  int * x_87;
  int * x_47;
  int * x_52;
  int * x_98;
  int * x_97;
  int x_14;
  int x_36;
  int x_90;
  int x_89;
  int x_48;
  int x_53;
  int x_100;
  int x_99;
  int x_15;
  int x_37;
  int x_92;
  int x_91;
  int x_50;
  int x_54;
  int x_102;
  int x_101;
  int x_55;
  int x_57;
  int * x_74;
  int x_77;
  int x_79;

L_8:
  x_29 = Dragon_Runtime_alloc_array(0, 10, 4); // (isPtr, size, scale);
  x_30 = x_29;
  x_87 = x_13;
  x_88 = x_87;
  x_89 = x_14;
  x_90 = x_89;
  x_91 = x_15;
  x_92 = x_91;
  if (1)
    goto L_10;
  else goto L_12;

L_10:
  x_35 = x_88;
  x_36 = x_90;
  x_37 = x_92;
  x_93 = 1;
  x_94 = x_93;
  x_95 = 1;
  x_96 = x_95;
  x_97 = x_35;
  x_98 = x_97;
  x_99 = x_36;
  x_100 = x_99;
  x_101 = x_37;
  x_102 = x_101;
  if (1)
    goto L_14;
  else goto L_16;

L_14:
  x_42 = x_94;
  x_46 = x_42;
  *(((A)x_30)+x_46) = x_46;
  x_47 = *(((A)x_30)+x_46);
  x_48 = x_46+1;
  x_49 = x_48;
  x_50 = x_49<10;
  x_93 = x_49;
  x_94 = x_93;
  x_95 = x_49;
  x_96 = x_95;
  x_97 = x_47;
  x_98 = x_97;
  x_99 = x_48;
  x_100 = x_99;
  x_101 = x_50;
  x_102 = x_101;
  if (x_50)
    goto L_14;
  else goto L_16;

L_16:
  x_51 = x_96;
  x_52 = x_98;
  x_53 = x_100;
  x_54 = x_102;
  x_55 = x_51+1;
  x_56 = x_55;
  x_57 = x_56<10;
  x_87 = x_52;
  x_88 = x_87;
  x_89 = x_53;
  x_90 = x_89;
  x_91 = x_54;
  x_92 = x_91;
  if (x_57)
    goto L_10;
  else goto L_12;

L_12:
  x_0(x_30);

L_18:
  x_103 = 0;
  x_104 = x_103;
  if (1)
    goto L_19;
  else goto L_21;

L_19:
  x_68 = x_104;
  x_74 = *(((A)x_30)+x_68);
  printi(x_74);

L_23:
  prints(x_105);

L_24:
  x_77 = x_68+1;
  x_78 = x_77;
  x_79 = x_78<10;
  x_103 = x_78;
  x_104 = x_103;
  if (x_79)
    goto L_19;
  else goto L_21;

L_21:
  return 0;

}

