#ifndef GEN_FRAME_H
#define GEN_FRAME_H


#include "machine.h"

Machine_Prog_t Machine_genFrame (Machine_Prog_t p);

#endif
