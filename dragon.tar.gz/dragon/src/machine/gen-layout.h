#ifndef GEN_LAYOUT_H
#define GEN_LAYOUT_H


#include "machine.h"

Machine_Prog_t Machine_genLayout (Machine_Prog_t p);

#endif
