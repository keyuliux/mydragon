#ifndef RUNTIME_H
#define RUNTIME_H

#include "../atoms/atoms.h"

extern Id_t Runtime_array;
extern Id_t Runtime_class;

void Runtime_init ();

#endif
