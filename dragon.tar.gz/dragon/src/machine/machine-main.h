#ifndef MACHINE_MAIN_H
#define MACHINE_MAIN_H

#include "machine.h"

Machine_Prog_t Machine_main (Machine_Prog_t p);

#endif
