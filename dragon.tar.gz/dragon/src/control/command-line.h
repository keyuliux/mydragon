#ifndef COMMAND_LINE_H
#define COMMAND_LINE_H

#include "../lib/list.h"

List_t CommandLine_doarg (int argc, char **argv);

#endif
