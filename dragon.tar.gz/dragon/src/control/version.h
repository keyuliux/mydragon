#ifndef VERSION_H
#define VERSION_H

#include "../lib/string.h"

extern String_t Version_version;

#endif
