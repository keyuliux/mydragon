class x
{
  x x;
}

x x (x x)
{
	x y = new x (null);
	y.x = null;
	{
	  x y = new x(null);
	  y.x = null;
	  return y.x;
  }
	return y.x;
}

int dragon ()
{
  return 0;
}
