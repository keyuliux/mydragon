int dragon ()
{
  int i = 0;
  int j = 1;
  
  {
    int i = 3;
    int j = 4;
  }
  return 0;
}
