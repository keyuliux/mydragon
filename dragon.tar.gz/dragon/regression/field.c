class a
{
  int x;
  int y;
}

int printa (a z)
{
  printi (z.x);
  prints (" ");
  printi (z.y);
  prints ("\n");
  return 0;
}

int dragon ()
{
  int[] z = new int [10];
  
  z[0] = 999;
  
  return 0;
}
