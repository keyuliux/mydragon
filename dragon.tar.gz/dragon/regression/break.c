int dragon ()
{
	int i=0;

	while (i<10){
	  printi (i);
	  prints ("\n");
	  if (i==5)
	    break;
	  i = i+1;
	}
	return 0;
}
