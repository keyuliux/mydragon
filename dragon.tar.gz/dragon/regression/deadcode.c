int dragon ()
{
  int r;
  r = printi (1+2*3);
  return 0;
  r = r+1;
  r = r+1;
  return r;
}
