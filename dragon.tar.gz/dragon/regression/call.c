int f (int first, int second, int third)
{
  prints ("the first one: ");
  printi (first);
  prints ("\nthe second one: ");
  printi (second);
  prints ("\nthe third one: ");
  printi (third);
  return 0;
}


int dragon ()
{
  f (3, 4, 5);
    
  return 0;
}
