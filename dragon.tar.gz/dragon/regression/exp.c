int dragon ()
{
  int a;
  int b;
  int c;
  int[] d;
  
  a = b + (-c);
  
  d[0] = 1;
    
    
  return 0;
}
