int dragon ()
{
  string s = "hello;
  {
    int s = 0;
    string t = ";
    return s;
  }
  return 0;
}
