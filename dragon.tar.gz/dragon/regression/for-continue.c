int dragon ()
{
  int i=0;
    
  for (i=0; i<10; i=i+1)
    printi (i);

  return 0;
}
