int main ()
{
  int x, y, z;

  (x = y) = z;

  return 0;
}
