int dragon ()
{
  int i = 1;
  int j = 10;
  
  @ 3 && 4;
  
  @ !3;
  
  @ 6 || 7;
  
  return 0;
}
