int dragon ()
{
  int sum = 0;
  int i;
  
  for (i = 0; i<=100; i=i+1)
    sum = sum +i;
    
  prints ("1+2+...+100 = ");
  printi (sum);
  
  return 0;
}
