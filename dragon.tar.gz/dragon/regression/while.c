int dragon ()
{
  int i = 9;
  while (i){
    i = i-1;
  }   
  printi (i);
  return 0;
}
