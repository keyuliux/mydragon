int dragon ()
{
  int a;
  
  a = 1+2+3+4+5;
  printi (a);
  
  return 0;
}
