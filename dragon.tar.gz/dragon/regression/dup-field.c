class s {int x; int x;}

int dragon ()
{
  int x;
  int x;
  int z;
  s k;
  
  k.x = 1;
  
  return 0;
}
