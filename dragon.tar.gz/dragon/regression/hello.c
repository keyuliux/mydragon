class A
{
  int x;
}

class B
{
  A x;
  B y;
}

int dragon (int argc, string[] argv)
{
  prints ("hello, world\n");
  f ();
  return 0;
}

int f ()
{
  A a;
  
  a = new A (999);
  printi (a.x);
  return 0;
}
