int dragon ()
{  
  throw;
  return 0;
}
