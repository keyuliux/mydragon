int dragon ()
{
	int z = 2;
	{
	  int z = 3;
	  printi (z);
	}
	
	return 0;
}

