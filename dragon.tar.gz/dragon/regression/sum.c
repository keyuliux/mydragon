int dragon ()
{
  int i = 0;
  int sum = 0;
  
  for (i=0; i<=100; i=i+1)
    sum = sum + i;
    
  printi (sum);
    
  return 0;
}
