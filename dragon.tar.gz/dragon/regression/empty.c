int dragon ()
{
  return 0;
}