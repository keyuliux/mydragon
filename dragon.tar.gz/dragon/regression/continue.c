int dragon ()
{
  int i=0;
  int j=10;
    
  while (i<=j){
    prints ("i===");
    printi (i);
    prints ("\nj===");
    printi (j);
    prints ("\n\n");
    
    i = i+1;
    continue;
  }
  return 0;
}
