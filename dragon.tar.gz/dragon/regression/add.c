int dragon ()
{
  int a; 
  a = 1;

  return 0;
}
